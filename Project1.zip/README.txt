Listing:
1) Memory.java
2) Project1.java
3) REAMDE.txt
4) Sample1.txt
5) Sample2.txt
6) Sample3.txt
7) Sample4.txt
8) Sample5.txt
9) summary.docx

Description:
1 - java source file
2 - java source file
3 - readme file with file listing, description and instructions how to run
4-7 - input samples
8 - created sample5.txt that prints HEY
9) word document with summary (purpose, how implemented, experience)

How to compile:
javac Project1.java
javac Memory.java

How to run:
java Project1 sample2.txt 30